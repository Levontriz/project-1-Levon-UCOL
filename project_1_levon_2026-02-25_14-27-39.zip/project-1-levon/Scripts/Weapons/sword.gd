extends DefaultPrimaryWeapon
class_name sword

var elapsedIn = 0.0
var elapsedOut = 0.0

var swinging = false

func fire():
	if swinging == false:
		swinging = true
		_swing()

func _swing():
	var tween = create_tween()
	tween.tween_method(func(angle): %Sword_Pivot.rotation = angle,
		%Sword_Pivot.rotation, deg_to_rad(-145), 0.2)
	tween.tween_method(func(angle): %Sword_Pivot.rotation = angle,
		deg_to_rad(-160), 0.0, 0.2)
	tween.tween_callback(func(): swinging = false)
	
func look_at_mouse(delta: float) -> void:
	# Get all sprites
	var direction = get_global_mouse_position() - global_position
	var target_angle = direction.angle()
	rotation = lerp_angle(rotation, target_angle, weapon_rotation_weight * delta)
