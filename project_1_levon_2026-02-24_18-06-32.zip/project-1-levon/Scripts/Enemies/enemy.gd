extends CharacterBody2D
class_name Enemy

@export var max_health: int = 10
@export var movement_speed: float = 10000.0

var current_health: int
var enemy_velocity: Vector2 = Vector2.ZERO

func _ready():
	current_health = max_health

func take_damage(amount: int):
	current_health -= amount
	if current_health <= 0:
		die()

func die():
	queue_free()

func _process(delta):
	# Base enemies might not have movement here, but specific enemies will override/add to this
	pass

func _physics_process(delta):
	move_and_slide()
