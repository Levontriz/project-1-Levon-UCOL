extends Enemy

@onready var walkAnimation = $ZombieSprite 
var player: CharacterBody2D

func _process(delta):
	# Specific behavior for the Slime
	var target_pos = player.global_position
	var direction = global_position.direction_to(target_pos)
	velocity = direction * movement_speed * delta
	
	if velocity != Vector2.ZERO:
		walkAnimation.play()
	else:
		walkAnimation.pause()
	# Add AI logic here (e.g., chase player)
	# See resources on AI like state machines or behavior trees for complex logic
